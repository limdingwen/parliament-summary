create view unscraped_sitting_dates_view(id, created_at, sitting_date) as
SELECT sd.id,
       sd.created_at,
       sd.sitting_date
FROM sitting_date sd
         LEFT JOIN sitting s ON sd.id = s.sitting_date_id
WHERE s.sitting_date_id IS NULL;

alter table unscraped_sitting_dates_view
    owner to postgres;

grant delete, insert, references, select, trigger, truncate, update on unscraped_sitting_dates_view to anon;

grant delete, insert, references, select, trigger, truncate, update on unscraped_sitting_dates_view to authenticated;

grant delete, insert, references, select, trigger, truncate, update on unscraped_sitting_dates_view to service_role;

