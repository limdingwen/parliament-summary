create function refresh_materialized_view(view_name text) returns void
    security definer
    SET search_path = ""
    language plpgsql
as
$$
BEGIN
    EXECUTE 'REFRESH MATERIALIZED VIEW ' || view_name;
END;
$$;

alter function refresh_materialized_view(text) owner to postgres;

grant execute on function refresh_materialized_view(text) to authenticated;

grant execute on function refresh_materialized_view(text) to service_role;

