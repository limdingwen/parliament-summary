create view debate_speech_full_text_view(debate_id, title, full_text) as
SELECT ds.debate_id,
       d.title,
       (((((COALESCE(ds.speaker_name, ''::text) || ' '::text) || ds.content) || ' '::text) ||
         COALESCE(d.summary, ''::text)) || ' '::text) || d.title AS full_text
FROM debate_speech ds
         JOIN debate d ON ds.debate_id = d.id;

alter table debate_speech_full_text_view
    owner to postgres;

grant delete, insert, references, select, trigger, truncate, update on debate_speech_full_text_view to anon;

grant delete, insert, references, select, trigger, truncate, update on debate_speech_full_text_view to authenticated;

grant delete, insert, references, select, trigger, truncate, update on debate_speech_full_text_view to service_role;

