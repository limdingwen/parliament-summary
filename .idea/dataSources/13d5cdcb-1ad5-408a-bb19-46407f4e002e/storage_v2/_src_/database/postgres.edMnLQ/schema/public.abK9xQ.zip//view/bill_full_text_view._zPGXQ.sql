create view bill_full_text_view(bill_no, name, full_text) as
SELECT bill.bill_no,
       bill.name,
       (((((bill.bill_no || ' '::text) || bill.name) || ' '::text) || COALESCE(bill.summary, ''::text)) || ' '::text) ||
       COALESCE(bill.original_text, ''::text) AS full_text
FROM public.bill;

alter table bill_full_text_view
    owner to postgres;

grant delete, insert, references, select, trigger, truncate, update on bill_full_text_view to anon;

grant delete, insert, references, select, trigger, truncate, update on bill_full_text_view to authenticated;

grant delete, insert, references, select, trigger, truncate, update on bill_full_text_view to service_role;

