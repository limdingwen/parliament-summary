create view combined_mp_names_view(mp_id, full_name, alias_name) as
SELECT DISTINCT m.id AS mp_id,
                m.full_name,
                a.alias_name
FROM mp m
         LEFT JOIN mp_aliases a ON m.id = a.mp_id;

alter table combined_mp_names_view
    owner to postgres;

grant delete, insert, references, select, trigger, truncate, update on combined_mp_names_view to anon;

grant delete, insert, references, select, trigger, truncate, update on combined_mp_names_view to authenticated;

grant delete, insert, references, select, trigger, truncate, update on combined_mp_names_view to service_role;

