create materialized view debate_bill_match_view as
SELECT d.id                                                                        AS debate_id,
       b.id                                                                        AS bill_id,
       (EXISTS (SELECT 1
                FROM debate_speech ds
                WHERE ds.debate_id = d.id
                  AND (lower(ds.content) ~~ '%order for second reading read%'::text OR
                       lower(ds.content) ~~ '%be now read a second time%'::text OR
                       lower(ds.content) ~~ '%now be read a second time%'::text))) AS is_second_reading
FROM debate d
         JOIN bill b ON d.title = b.name;

alter materialized view debate_bill_match_view owner to postgres;

grant delete, insert, references, trigger, truncate, update on debate_bill_match_view to anon;

grant delete, insert, references, trigger, truncate, update on debate_bill_match_view to authenticated;

grant delete, insert, references, select, trigger, truncate, update on debate_bill_match_view to service_role;

