create view debate_sortable_view(id, title, order_no, summary, sitting_date) as
SELECT d.id,
       d.title,
       d.order_no,
       d.summary,
       sd.sitting_date
FROM debate d
         JOIN sitting s ON d.sitting_id = s.id
         JOIN sitting_date sd ON s.sitting_date_id = sd.id;

alter table debate_sortable_view
    owner to postgres;

grant delete, insert, references, select, trigger, truncate, update on debate_sortable_view to anon;

grant delete, insert, references, select, trigger, truncate, update on debate_sortable_view to authenticated;

grant delete, insert, references, select, trigger, truncate, update on debate_sortable_view to service_role;

